import HomeController from './HomeController'
import AboutController from './AboutController'
import ProjectsController from './ProjectsController'
import Settings from './Settings'
const Controllers = {
    HomeController: Object.assign(HomeController, HomeController),
AboutController: Object.assign(AboutController, AboutController),
ProjectsController: Object.assign(ProjectsController, ProjectsController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers