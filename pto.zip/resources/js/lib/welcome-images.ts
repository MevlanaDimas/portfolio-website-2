export const WELCOME_BACKGROUND_IMAGES = [
    "/shot-breathtaking-giant-mountain-covered-forests-gleaming-cloudy-sky-min.jpg",
    "/mountain-forest-blue-sky-min.jpg",
    "/mountain-clear-day-min.jpg",
    "/landscape-temple-clouds-top-batur-volcano-bali-indonesia-min.jpg",
    "/landscape-dawn-overlooking-volcano-batur-volcano-bali-indonesia-min.jpg",
    "/cloudy-mountains-landscape-min.jpg",
    "/beautiful-landscape-min.jpg",
    "/wmremove-transformed.jpeg"
];
